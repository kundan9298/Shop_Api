<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\ProductController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


Route::controller(AuthController::class)->group(function(){
    Route::post('login', 'login');
    Route::post('register', 'register');
    Route::post('logout', 'logout');
});


Route::controller(UserController::class)->group(function(){
    Route::post('user_login', 'user_login');
    Route::post('user_register', 'user_register');
    Route::post('user_logout', 'user_logout');
});

// Route::get('all_product', [ProductController::class, 'all_product']);


// Route::get('all_product', [ProductController::class, 'all_product']);




Route::middleware('auth:sanctum')->group( function () {

    Route::post('add_to_cart', [UserController::class, 'add_to_cart']);
    Route::post('delete_from_cart/{id}', [UserController::class, 'delete_from_cart']);
    Route::post('cart_product_update/{id}', [UserController::class, 'cart_product_update']);
    Route::get('view_all_cartData', [UserController::class, 'view_all_cartData']);

});




Route::middleware('auth:sanctum')->group( function () {
    Route::controller(ProductController::class)->group(function(){
        Route::post('add', 'add');
        Route::delete('delete/{id}', 'delete');
        Route::post('update/{id}', 'update');
        Route::get('all_product', 'all_product');
        // Route::post('register', 'register');
    });
});


