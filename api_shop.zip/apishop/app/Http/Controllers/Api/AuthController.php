<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Validator;
use App\Models\User;
use Auth;
class AuthController extends Controller
{
    public function register(Request $request){
        $validator = validator::make($request->all(),[
            'name' => 'required',
            'email' => 'required | email',
            'password' => 'required',
            'c_password' => 'required |same:password',
        ]);

        if($validator->fails()){
            $response = [
                'success' => 0,
                'message' => $validator->error()
            ];
            return response()->json($response, 500);
        }

        $input = $request->all();
        $input['password'] = bcrypt($input['password']);
        $user = User::create($input);
        $success['token'] = $user->createToken('Myapp')->plainTextToken;
        $success['name'] = $user->name;

        $response = [
            'success' => true,
            'data' => $success,
            'message' => 'register successful'
        ];
        return response()->json($response, 200);
    }


    public function login(Request $request){
        if(Auth::attempt(['email' => $request->email, 'password'=> $request->password])){
            $user = Auth::user();

            $success['token'] = $user->createToken('Myapp')->plainTextToken;
            $success['name'] = $user->name;
    
            $response = [
                'success' => true,
                'data' => $success,
                'message' => 'login successful'
            ];
            return response()->json($response, 200);
        }else{
            $response = [
                'success' => 0,
                
                'message' => 'unauthorized'
            ];
            return response()->json($response, 500);

        }

    }


    public function logout(Request $request){
        Auth::logout();
        $response = [
            'success' => true,
            
            'message' => 'logout successfully'
        ];
        return response()->json($response, 200);
    }
}
