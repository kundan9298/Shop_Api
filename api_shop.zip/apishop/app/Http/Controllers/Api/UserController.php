<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use Validator;
use App\Models\User;
use App\Models\Product;
use Auth;
use App\Models\Cart;

class UserController extends Controller
{
    public function user_register(Request $request){
        $validator = validator::make($request->all(),[
            'name' => 'required',
            'email' => 'required | email',
            'password' => 'required',
            'c_password' => 'required |same:password',
        ]);

        if($validator->fails()){
            $response = [
                'status' => 0,
                'message' => $validator->error()
            ];
            return response()->json($response, 500);
        }

        $input = $request->all();
        $input['password'] = bcrypt($input['password']);
        $user = User::create($input);
        $success['token'] = $user->createToken('Myapp')->plainTextToken;
        $success['name'] = $user->name;

        $response = [
            'success' => 1,
            'data' => $success,
            'message' => 'register successful'
        ];
        return response()->json($response, 200);
    }


    public function user_login(Request $request){
        if(Auth::attempt(['email' => $request->email, 'password'=> $request->password])){
            $user = Auth::user();

            $success['token'] = $user->createToken('Myapp')->plainTextToken;
            $success['name'] = $user->name;
    
            $response = [
                'success' => 1,
                'data' => $success,
                'message' => 'login successful'
            ];
            return response()->json($response, 200);
        }else{
            $response = [
                'success' => 0,
                
                'message' => 'unauthorized'
            ];
            return response()->json($response, 200);

        }

    }


    public function user_logout(Request $request){
        Auth::logout();
        $response = [
            'success' => true,
            
            'message' => 'logout successfully'
        ];
        return response()->json($response, 200);
    }


    public function add_to_cart(Request $request){

        $loginCheck = $request->user()->id;

        if($loginCheck == null){
            return response()->json([
                
                'message' => "Not add in cart",
                'status' =>0,

            ]);
        }else{
            $cartData = new Cart();

            $cartData->user_id = $request->user()->id;
            $cartData->qty = $request->qty;
            $cartData->product_id = $request->product_id;
            $cartData->save();


            return response()->json([
                'data' => $cartData,
                'message' => "successfully add in cart",

                'status' =>1

            ]);
        }

    

    }


    public function view_all_cartData(Request $request){
        $userID = $request->user()->id;  
        if($userID){
            $products = DB::table('users')
            ->join('carts', 'users.id', '=', 'carts.user_id')
            ->join('products', 'carts.product_id', '=', 'products.id')
            ->select('products.*')
            ->where('users.id', '=', $userID)
            ->get();
                
            return  response()->json(
              [
                'data' => $products,
                'message' => 'product find successfully',
                'status' => 1

              ]);

        }else{
            return  response()->json(
                [
                  
                  'message' => 'product not find ',
                  'status' => 0
  
                ]);

        }

    }




    public function delete_from_cart(Request $request, $id){

        $data = Cart::find($id);
        if($data){
            $data->delete();
            $response = [
                'success' => 1,
                'data' => $data,
                'message' => 'product delete from cart successful'
            ];
            return response()->json($response, 200);

        }else{
        
            $response = [
                'success' => 0,
                'data' => $data,
                'message' => 'product not delete  from cart'
            ];
            return response()->json($response, 200);
        }
    }




    public function cart_product_update(Request $request, $id){
        $data = Cart::find($id);

        if($data){

            $data->qty = $request->qty;
            $data->save();
            $response = [
                'success' => 1,
                'data' => $data,
                'message' => 'product add successful'
            ];
            return response()->json($response, 200);
        }else{
            $response = [
                'success' => 0,
                'data' => $data,
                'message' => 'product add successful'
            ];
            return response()->json($response, 500);
        }
    }

}
