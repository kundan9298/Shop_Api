<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Cart;
use Validator;

class ProductController extends Controller
{
    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'qty' => 'required',
            'color' => 'required',
            'size' =>'required',

        ]);

        if($validator->fails()){
            $response = [
                'success' => 0,
                'message' => $validator->error()
            ];
            return response()->json($response, 200);
        }else{
            $input = $request->all();
        $user = Product::create($input);
        $response = [
            'success' => true,
            'data' => $user,
            'message' => 'product add successful'
        ];
        return response()->json($response, 200);
        }
    }



    public function all_product(Request $request){
        $data = Product::all();
        $response = [
            'success' => 1,
            'data' => $data,
            'message' => 'All Product get successful'
        ];
        return response()->json($response, 200);
        
    }


    public function delete($id){

        $data = Product::find($id);
        if($data){
            $data->delete();
            $response = [
                'success' => 1,
                'data' => $data,
                'message' => 'product delete successful'
            ];
            return response()->json($response, 200);

        }else{
        
            $response = [
                'success' => 0,
                'data' => $data,
                'message' => 'product not delete '
            ];
            return response()->json($response, 500);
        }
    }


    public function update(Request $request, $id){

        $data = Product::find($id);

        if($data){

            $data->name = $request->name;
            $data->qty = $request->qty;
            $data->color = $request->color;
            $data->size = $request->size;
            $data->save();
            $response = [
                'success' => 1,
                'data' => $data,
                'message' => 'product update successful'
            ];
            return response()->json($response, 200);
        }else{
            $response = [
                'success' => 0,
               
                'message' => 'product add successful'
            ];
            return response()->json($response, 500);
        }

   
        

    }


    


    
}
